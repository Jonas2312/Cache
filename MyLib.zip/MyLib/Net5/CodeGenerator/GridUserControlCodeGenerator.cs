﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.CodeGenerator
{
    public static class GridUserControlCodeGenerator
    {
        public static string GenerateCode(int numRows, int numColumns, string objectName, IDictionary<string, string> attributes = null, bool oneLine = true)
        {
            string s = string.Empty;

            s += "<Grid.RowDefinitions>\n";
            for (int i = 0; i < numRows; i++)
                s += "<RowDefinition Height=\"*\" />\n";            
            s += "</Grid.RowDefinitions>\n";
            s += "<Grid.ColumnDefinitions>\n";
            for (int i = 0; i < numColumns; i++)
                s += "< ColumnDefinition Width=\"*\" />\n";
            s += "</Grid.ColumnDefinitions>\n";

            string attributeString = string.Empty;
            if (attributes != null)
                foreach (var attribute in attributes)
                {
                    attributeString += attribute.Key;
                    attributeString += $"=\"{attribute.Value}\" ";
                }

            for (int i = 0; i < numRows; i++)
            {
                for(int j = 0; j < numColumns; j++)
                {
                    string line = $"<{objectName} ";
                    line += $"Grid.Row=\"{i}\" Grid.Column=\"{j}\" ";
                    line += attributeString;
                    if (oneLine)
                        line += "/>\n";
                    else
                        line += $">\n\n<\\{objectName}>\n";
                    
                    s += line;
                }
            }
            return s;
        }
    }
}
