﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.CodeGenerator
{
    public static class EqualsCodeGenerator
    {
        public static string GenerateCode(Type type)
        {
            string abc = GenerateEqualsMethod(type);
            abc += "\n\n";
            return abc + GenerateHashcodeMethod(type);
        }

        public static string GenerateEqualsMethod(Type type)
        {
            string s = string.Empty;
            string typeName = type.Name;
            typeName = typeName[0].ToString().ToLower() + typeName.Substring(1);
            int index = typeName.IndexOf('`');
            typeName = index == -1 ? typeName : typeName.Substring(0, index);

            s += "public override bool Equals(object obj)\n";
            s += "{\n";
            s += $"    var {typeName} = obj as INSERT_CLASSNAME;\n";
            s += $"    if ({typeName} == null)\n";
            s += $"        return false;\n";
            if (type.GetProperty("Count") != null)
            {
                s += $"    if ({typeName}.Count != Count)\n";
                s += $"        return false;\n";
            }
            s += $"    return {typeName}.GetHashCode() == this.GetHashCode();\n";
            s += "}\n";
            return s;
        }

        public static string GenerateHashcodeMethod(Type type)
        {
            string s = string.Empty;
            string typeName = type.Name;
            typeName = typeName[0].ToString().ToLower() + typeName.Substring(1);
            int index = typeName.IndexOf('`');
            typeName = index == -1 ? typeName : typeName.Substring(0, index);

            s += "public override int GetHashCode()\n";
            s += "{\n";
            s += $"    var hashCode = 1;\n";
            s += $"    foreach (var element in this)\n";
            s += "    {\n";
            s += $"        hashCode = HashCode.Combine(hashCode, element);\n";
            s += "    }\n";
            s += "    return hashCode;\n";
            s += "}\n";
            return s;
        }

    }
}
