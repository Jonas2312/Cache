﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.ExampleClasses
{
    class ExampleClass1<TObject, TExample> : List<TObject>
    {
        public override bool Equals(object obj)
        {
            var exampleClass1 = obj as ExampleClass1<TObject, TExample>;
            if (exampleClass1 == null)
                return false;
            if (exampleClass1.Count != Count)
                return false;
            return exampleClass1.GetHashCode() == this.GetHashCode();
        }

        public override int GetHashCode()
        {
            var hashCode = 1;
            foreach (var element in this)
            {
                hashCode = HashCode.Combine(hashCode, element);
            }
            return hashCode;
        }
    }
}
