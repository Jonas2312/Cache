﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.PerformanceMeasurement
{
    public static class PerformanceMeasurementHelper
    {
        #region SingleExecution
        public static void ExecuteMethod(Action action, out long ticksTaken)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            action.Invoke();
            stopwatch.Stop();
            TimeSpan stopwatchElapsed = stopwatch.Elapsed;
            ticksTaken = stopwatch.ElapsedTicks;
        }

        public static TOutput ExecuteMethod<TOutput>(Func<TOutput> function, out long ticksTaken)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            var output = function();
            stopwatch.Stop();
            TimeSpan stopwatchElapsed = stopwatch.Elapsed;
            ticksTaken = stopwatch.ElapsedTicks;
            return output;
        }


        public static TOutput ExecuteMethod<TInput, TOutput>(Func<TInput, TOutput> function, TInput input, out long ticksTaken)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            var output = function(input);
            stopwatch.Stop();
            TimeSpan stopwatchElapsed = stopwatch.Elapsed;
            ticksTaken = stopwatch.ElapsedTicks;
            return output;
        }


        public static TOutput ExecuteMethod<TInput1, TInput2, TOutput>(Func<TInput1, TInput2, TOutput> function, TInput1 input1, TInput2 input2, out long ticksTaken)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            var output = function(input1, input2);
            stopwatch.Stop();
            TimeSpan stopwatchElapsed = stopwatch.Elapsed;
            ticksTaken = stopwatch.ElapsedTicks;
            return output;
        }
        #endregion

        #region Average of multiple Executions
        public static void ExecuteMethodAverageNExecutions(Action setup, Action action, int n, out long ticksTaken)
        {
            ticksTaken = 0;
            for (int i = 0; i < n; i++)
            {
                if (setup != null)
                    setup.Invoke();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                action.Invoke();
                stopwatch.Stop();
                TimeSpan stopwatchElapsed = stopwatch.Elapsed;
                ticksTaken += stopwatch.ElapsedTicks;
            }
            ticksTaken = ticksTaken / n;
        }

        public static TOutput ExecuteMethodAverageNExecutions<TOutput>(Action setup, Func<TOutput> function, int n, out long ticksTaken)
        {
            ticksTaken = 0;
            TOutput output = default;
            for (int i = 0; i < n; i++)
            {
                if (setup != null)
                    setup.Invoke();
                TOutput temp;
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                temp = function();
                stopwatch.Stop();
                TimeSpan stopwatchElapsed = stopwatch.Elapsed;
                ticksTaken += stopwatch.ElapsedTicks;
                if (i == n - 1)
                    output = temp;
            }
            ticksTaken = ticksTaken / n;
            return output;
        }


        public static TOutput ExecuteMethodAverageNExecutions<TInput, TOutput>(Action setup, Func<TInput, TOutput> function, TInput input, int n, out long ticksTaken)
        {
            
            ticksTaken = 0;
            TOutput output = default;
            for (int i = 0; i < n; i++)
            {
                if (setup != null)
                    setup.Invoke();
                TOutput temp; 
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                temp = function(input);
                stopwatch.Stop();
                TimeSpan stopwatchElapsed = stopwatch.Elapsed;
                ticksTaken += stopwatch.ElapsedTicks;
                if (i == n - 1)
                    output = temp;
            }
            ticksTaken = ticksTaken / n;
            return output;
        }


        public static TOutput ExecuteMethodAverageNExecutions<TInput1, TInput2, TOutput>(Action setup, Func<TInput1, TInput2, TOutput> function, TInput1 input1, TInput2 input2, int n, out long ticksTaken)
        {
            ticksTaken = 0;
            TOutput output = default;
            for (int i = 0; i < n; i++)
            {
                if (setup != null)
                    setup.Invoke();
                TOutput temp;
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                temp = function(input1, input2);
                stopwatch.Stop();
                TimeSpan stopwatchElapsed = stopwatch.Elapsed;
                ticksTaken += stopwatch.ElapsedTicks;
                if (i == n - 1)
                    output = temp;
            }
            ticksTaken = ticksTaken / n;
            return output;
        }
        #endregion
    }
}
