﻿using Net5.CodeGenerator;
using Net5.ExampleClasses;
using Net5.PerformanceMeasurement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    class Program
    {
        static void Main(string[] args)
        {
            CacheTests1.CacheTest4();
            Console.WriteLine("Finished.");
            Console.ReadLine();
        }

        static void GridUserControlCodeGeneratorTest()
        {
            var v = new Dictionary<string, string>
            {
                { "Width", "50" },
                { "Height", "20" }
            };
            var s = GridUserControlCodeGenerator.GenerateCode(5, 5, "Button", attributes: v);
            Console.WriteLine(s);
        }


        static void EqualsCodeGeneratorTest()
        {
            var s = EqualsCodeGenerator.GenerateCode(typeof(ExampleClass1<object, object>));
            Console.WriteLine(s);
        }

    }
}
