﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    public abstract class SequenceEqualConcurrentBag<T> : ConcurrentBag<T>, IEnumerable<T>
    {
        public SequenceEqualConcurrentBag()
        {

        }

        public SequenceEqualConcurrentBag(IList<T> list)
        {
            foreach(var element in list)
            {
                Add(element);
            }
        }

        public override bool Equals(object obj)
        {
            var sequenceEqualConcurrentBag = obj as SequenceEqualConcurrentBag<T>;
            if (sequenceEqualConcurrentBag == null)
                return false;
            lock (sequenceEqualConcurrentBag)
            {
                lock (this)
                {
                    if (sequenceEqualConcurrentBag.Count != Count)
                        return false;
                    return sequenceEqualConcurrentBag.GetHashCode() == this.GetHashCode();
                }
            }
                    
        }

        public override int GetHashCode()
        {
            var hashCode = 1;
            lock (this)
            {
                foreach (var element in this)
                {
                    hashCode = HashCode.Combine(hashCode, element);
                }
            }
            return hashCode;
        }

        public override string ToString()
        {
            var s = string.Empty;
            int i = 0;
            lock (this)
            {
                foreach (var element in this)
                {
                    s += element;
                    if (i < Count - 1)
                        s += ", ";
                    i++;
                }
            }
            return s;
        }
    }
}
