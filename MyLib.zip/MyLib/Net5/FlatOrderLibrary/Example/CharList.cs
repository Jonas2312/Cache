﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.DynamicProgrammingLibrary.Example
{
    class CharList : SequenceEqualList<char>, IList<char>
    {
        public CharList() : base()
        {
        }

        public CharList(IList<char> list) : base(list)
        {
        }
    }
}
