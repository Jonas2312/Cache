﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.DynamicProgrammingLibrary.Example
{
    public class StringPermutations : SequenceEqualList<string>
    {
        IList<StringPermutations> _subPermutations;

        public StringPermutations() : base()
        {

        }
        public StringPermutations(List<string> list) : base(list)
        {

        }

        public StringPermutations(IList<StringPermutations> subPermutations)
        {
            _subPermutations = subPermutations;
        }

        public StringPermutations(string s)
        {
            Add(s);
        }

        public StringPermutations aufloesen()
        {
            var newPermutations = new StringPermutations();
            foreach (var subpermutation in _subPermutations)
            {
                //newPermutations = combineWithThis
            }
            return null;
        }

        public StringPermutations combine(StringPermutations permutation1, StringPermutations permutation2)
        {
            var newPermutations = new StringPermutations();
            foreach(var v in permutation1)
            {
                foreach(var x in permutation2)
                {
                    newPermutations.Add(v + x);
                }
            }
            return newPermutations;
        }

        internal void AppendToAll(char c)
        {
            var copy = new StringPermutations(this);
            foreach (var s in copy)
            {
                var newString = s + c.ToString();
                this.Add(newString);
                this.Remove(s);
            }
        }

        internal StringPermutations AppendToAllAndCopy(char c)
        {
            var copy = new StringPermutations(this);
            foreach (var s in this)
            {
                var newString = s + c.ToString();
                copy.Add(newString);
            }
            return copy;
        }
    }
}
