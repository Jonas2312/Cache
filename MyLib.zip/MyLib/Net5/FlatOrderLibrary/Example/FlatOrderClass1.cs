﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    public class FlatOrderClass1 : SequenceEqualDictionary<int, string>
    {
        public FlatOrderClass1(IDictionary<int, string> dictionary) : base(dictionary)
        {

        }
    }
}
