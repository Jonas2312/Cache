﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    public abstract class SequenceEqualList<T> : List<T>
    {
        public SequenceEqualList()
        {

        }

        public SequenceEqualList(IList<T> list)
        {
            foreach(var element in list)
            {
                Add(element);
            }
        }

        public override bool Equals(object obj)
        {
            var sequenceEqualList = obj as SequenceEqualList<T>;
            if (sequenceEqualList == null)
                return false;
            if (sequenceEqualList.Count != Count)
                return false;
            return sequenceEqualList.GetHashCode() == this.GetHashCode();
        }

        public override int GetHashCode()
        {
            var hashCode = 1;
            foreach(var element in this)
            {
                hashCode = HashCode.Combine(hashCode, element);
            }
            return hashCode;
        }

        public override string ToString()
        {
            var s = string.Empty;
            for(int i = 0; i < Count; i++)
            {
                s += this[i];
                if (i < Count - 1)
                    s += ", ";
            }
            return s;
        }
    }
}
