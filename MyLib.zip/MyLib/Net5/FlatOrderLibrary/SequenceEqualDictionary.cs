﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    public abstract class SequenceEqualDictionary<TKey, TValue> : Dictionary<TKey, TValue>
    {
        public SequenceEqualDictionary()
        {

        }

        public SequenceEqualDictionary(IDictionary<TKey, TValue> dictionary)
        {
            foreach(var element in dictionary)
            {
                Add(element.Key, element.Value);
            }
        }

        public override bool Equals(object obj)
        {
            var sequenceEqualDictionary = obj as SequenceEqualDictionary<TKey, TValue>;
            if (sequenceEqualDictionary == null)
                return false;
            if (sequenceEqualDictionary.Count != Count)
                return false;            
            return sequenceEqualDictionary.GetHashCode() == this.GetHashCode();
        }

        public override int GetHashCode()
        {
            var hashCode = 1;
            foreach (var element in this)
            {
                hashCode = HashCode.Combine(hashCode, element.Key, element.Value);
            }
            return hashCode;
        }

        public override string ToString()
        {
            var s = string.Empty;
            int i = 0;
            foreach(var element in this)
            {
                s += element.Key + " -- " + element.Value;
                if (i < Count - 1)
                    s += ", ";
                i++;
            }
            return s;
        }
    }
}
