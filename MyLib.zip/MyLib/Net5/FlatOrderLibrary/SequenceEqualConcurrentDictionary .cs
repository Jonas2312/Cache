﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    public abstract class SequenceEqualConcurrentDictionary<TKey, TValue> : ConcurrentDictionary<TKey, TValue>, IDictionary<TKey, TValue>
    {
        public SequenceEqualConcurrentDictionary()
        {

        }

        public SequenceEqualConcurrentDictionary(IDictionary<TKey, TValue> dictionary)
        {
            foreach(var element in dictionary)
            {
                TryAdd(element.Key, element.Value);
            }
        }

        public override bool Equals(object obj)
        {            
            var sequenceEqualConcurrentDictionary = obj as SequenceEqualConcurrentDictionary<TKey, TValue>;
            if (sequenceEqualConcurrentDictionary == null)
                return false;
            lock (sequenceEqualConcurrentDictionary)
            {
                lock (this)
                {
                    if (sequenceEqualConcurrentDictionary.Count != Count)
                        return false;
                    return sequenceEqualConcurrentDictionary.GetHashCode() == this.GetHashCode();
                }
            }
            
        }

        public override int GetHashCode()
        {
            var hashCode = 1;
            lock (this)
            {
                foreach (var element in this)
                {
                    hashCode = HashCode.Combine(hashCode, element.Key, element.Value);
                }
            }
            return hashCode;
        }

        public override string ToString()
        {
            var s = string.Empty;
            int i = 0;
            lock (this)
            {
                foreach (var element in this)
                {
                    s += element.Key + " -- " + element.Value;
                    if (i < Count - 1)
                        s += ", ";
                    i++;
                }
            }
            return s;
        }
    }
}
