﻿using Net5.PerformanceMeasurement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    public static class CacheTests1
    {

        static void CacheTest()
        {
            MyExampleCacheManager cacheManager = new MyExampleCacheManager();
            var random = new Random();

            var action = new Action<int>((int index) =>
            {
                string s = string.Empty;
                var v = random.Next(0, 50);
                s += index.ToString();
                s += " - " + v.ToString() + ": ";
                s += cacheManager.GetStringFromInt(v);
                Console.WriteLine(s);
            });
            DynamicProgrammingHelper.ExecuteParallelNTimes(action, 2000);


            for (int i = 0; i < 200; i++)
                Console.WriteLine($"{i}: " + cacheManager.CalculateStringFromInt(random.Next(0, 50)));

        }

        static void CacheTest2()
        {
            MyExampleCacheManager cacheManager = new MyExampleCacheManager();
            var random = new Random();
            int n = 20000;
            var func = new Func<int, string>((int index) =>
            {
                string s = string.Empty;
                var v = random.Next(0, 50);
                s += index.ToString();
                s += " - " + v.ToString() + ": ";
                s += cacheManager.GetStringFromInt(v);
                return s;
            });
            Console.WriteLine("Press enter to start calculation with Multihreading and Cache: ");
            Console.ReadLine();
            Console.WriteLine($"Generating {n} results...");
            var result = DynamicProgrammingHelper.ExecuteParallelNTimes(func, n);
            Console.WriteLine("Press enter to show results with Multihreading and Cache: ");
            Console.ReadLine();


            Console.ReadLine();
            for (int i = 0; i < result.Length; i++)
            {
                Console.WriteLine(result[i]);
            }

            Console.WriteLine("Press enter to start calculation without Multihreading and Cache: ");
            Console.ReadLine();
            for (int i = 0; i < n; i++)
                Console.WriteLine($"{i}: " + cacheManager.CalculateStringFromInt(random.Next(0, 50)));

        }


        public static void CacheTest3()
        {
            MyExampleCacheManager cacheManager = new MyExampleCacheManager();
            var random = new Random();

            var input = new int[10000];

            for (int i = 0; i < input.Length; i++)
            {
                var v = random.Next(0, 100);
                input[i] = v;
            }

            var func = new Func<int, int, string>((int input, int index) =>
            {
                string s = string.Empty;
                s += "Iteration index is ";
                s += index.ToString();
                s += " - expected value: " + input.ToString() + ", actual value: ";
                string resultString = cacheManager.GetStringFromInt(input);
                int result = cacheManager.GetIntFromString(resultString);
                s += result;
                return s;
            });

            Console.WriteLine("Press enter to start calculation with Multihreading and Cache: ");
            Console.ReadLine();
            Console.WriteLine($"Generating {input.Length} results...");
            var result = DynamicProgrammingHelper.ExecuteParallelNTimes(func, input);
            Console.WriteLine("Finished Generatin results.");

            Console.WriteLine("Press enter to show results with Multihreading and Cache: ");
            Console.ReadLine();

            for (int i = 0; i < result.Length; i++)
            {
                Console.WriteLine(result[i]);
            }


            Console.WriteLine("Press enter to start calculation without Multihreading and Cache: ");
            Console.ReadLine();
            for (int i = 0; i < input.Length; i++)
                Console.WriteLine($"Iteration index is {i} - expected value: {input[i]}, actual value: " + cacheManager.CalculateIntFromString(cacheManager.CalculateStringFromInt(input[i])));

        }

        public static void CacheTest4()
        {
            JustFillCache(10);
            WithInefficiencies(100000, 10, 20);
            WithNoIneffiencies(100000, 10);

        }


        static void JustFillCache(int differentValues)
        {
            MyExampleCacheManager cacheManager = new MyExampleCacheManager();
            Action clearCache = new Action(() =>
            {
                cacheManager.ClearAllCaches();
            });

            var random = new Random();

            var input = new int[differentValues];

            for (int i = 0; i < input.Length; i++)
            {
                var v = i;
                input[i] = v;
            }

            var fillCache = new Func<int, int, string>((int input, int index) =>
            {
                string s = string.Empty;
                s += "Iteration index is ";
                s += index.ToString();
                s += " - expected value: " + input.ToString() + ", actual value: ";
                string resultString = cacheManager.GetStringFromInt(input);
                int result = cacheManager.GetIntFromString(resultString);
                s += result;
                return s;
            });

            Console.WriteLine("Press enter to Fill Cache: ");
            Console.WriteLine($"Generating {input.Length} results...");
            long ticks = 0;
            var fillCache2 = new Func<string[]>(() =>
            {
                return DynamicProgrammingHelper.ExecuteParallelNTimes(fillCache, input);
            });
            var result = PerformanceMeasurementHelper.ExecuteMethodAverageNExecutions(clearCache, fillCache2, 10, out ticks);
            Console.WriteLine($"Finished Generatin results in averagely {TimeSpan.FromTicks(ticks).TotalMilliseconds} milliseconds. \n\n");

        }

        static void WithInefficiencies(int inputSize, int differentValues, int numIneffiencies)
        {
            MyExampleCacheManager cacheManager = new MyExampleCacheManager();
            Action clearCache = new Action(() =>
            {
                cacheManager.ClearAllCaches();
            });

            var random = new Random();

            var input = new int[inputSize];

            for (int i = 0; i < input.Length; i++)
            {
                var v = random.Next(0, differentValues);
                input[i] = v;
            }

            var funcIneffiencies = new Func<int, int, string>((int input, int index) =>
            {
                string s = string.Empty;
                s += "Iteration index is ";
                s += index.ToString();
                s += " - expected value: " + input.ToString() + ", actual value: ";
                string resultString = cacheManager.GetStringFromInt(input);
                int result = cacheManager.GetIntFromString(resultString);
                // Simulate algorithmic inenficciency
                for (int i = 0; i < numIneffiencies; i++)
                {
                    resultString = null;
                    resultString = cacheManager.GetStringFromInt(result);
                    result = 0;
                    result = cacheManager.GetIntFromString(resultString);
                }
                s += result;
                return s;
            });

            Console.WriteLine("Press enter to start calculation with Multihreading and Cache and Ineffiencies: ");

            Console.WriteLine($"Generating {input.Length} results...");
            long ticks = 0;
            var funcIneffiencies2 = new Func<string[]>(() =>
            {
                return DynamicProgrammingHelper.ExecuteParallelNTimes(funcIneffiencies, input);
            });
            var result = PerformanceMeasurementHelper.ExecuteMethodAverageNExecutions(clearCache, funcIneffiencies2, 10, out ticks);
            Console.WriteLine($"Finished Generatin results in averagely {TimeSpan.FromTicks(ticks).TotalMilliseconds} milliseconds. \n\n");


        }


        public static void WithNoIneffiencies(int inputSize, int differentValues)
        {
            MyExampleCacheManager cacheManager = new MyExampleCacheManager();
            Action clearCache = new Action(() =>
            {
                cacheManager.ClearAllCaches();
            });

            var random = new Random();
            var input = new int[inputSize];
            for (int i = 0; i < input.Length; i++)
            {
                var v = random.Next(0, differentValues);
                input[i] = v;
            }

            var funcNoIneffieciency = new Func<int, int, string>((int input, int index) =>
            {
                string s = string.Empty;
                s += "Iteration index is ";
                s += index.ToString();
                s += " - expected value: " + input.ToString() + ", actual value: ";
                string resultString = cacheManager.GetStringFromInt(input);
                int result = cacheManager.GetIntFromString(resultString);
                s += result;
                return s;
            });

            Console.WriteLine("Press enter to start calculation with Multihreading and Cache and No Ineffiencies: ");

            Console.WriteLine($"Generating {input.Length} results...");
            long ticks = 0;
            var funcNoIneffieciency2 = new Func<string[]>(() =>
            {
                return DynamicProgrammingHelper.ExecuteParallelNTimes(funcNoIneffieciency, input);
            });
            var result = PerformanceMeasurementHelper.ExecuteMethodAverageNExecutions(clearCache, funcNoIneffieciency2, 10, out ticks);
            Console.WriteLine($"Finished Generatin results in averagely {TimeSpan.FromTicks(ticks).TotalMilliseconds} milliseconds. \n\n");

            foreach(var v in cacheManager.GetFromCache(cacheManager.CalculateStringFromInt, input))
            {
                Console.WriteLine(v);
            }

        }
    }
}
