﻿using Net5.DynamicProgrammingLibrary.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    interface IMyCacheManager : IMultithreadedCacheManager
    {
        string GetStringFromInt(int i);
        int GetIntFromString(string s);
    }
}
