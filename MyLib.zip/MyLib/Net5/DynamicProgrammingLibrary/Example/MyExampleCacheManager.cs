﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    class MyExampleCacheManager : MultithreadedCacheManager, IMyCacheManager
    {
        public MyExampleCacheManager()
        {
            RegisterCache<int, string>(CalculateStringFromInt);
            RegisterCache<string, int>(CalculateIntFromString);
        }

        public int GetIntFromString(string s)
        {
            return GetFromCache(CalculateIntFromString, s);
        }

        public string GetStringFromInt(int i)
        {
            return GetFromCache(CalculateStringFromInt, i);
        }

        public int CalculateIntFromString(string s)
        {
            var y = 1;
            for (int x = 0; x < 49999999; x++)
                y = (y + x) / (x + 1);
            return s.Length;
        }

        public string CalculateStringFromInt(int i)
        {
            string s = string.Empty;
            var y = 1;
            for (int x = 0; x < 49999999; x++)
                y = (y + x) / (x+1);
            for (int x = 0; x < i*y; x++)
                s += "x";
            return s;
        }
    }
}
