﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.DynamicProgrammingLibrary.Example
{
    public interface IDictionaryCache<TKey, TValue> : ICache<TKey, TValue>
    {

    }
}
