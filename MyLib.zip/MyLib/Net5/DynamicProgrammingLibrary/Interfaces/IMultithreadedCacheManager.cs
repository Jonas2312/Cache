﻿using Net5.DynamicProgrammingLibrary.Example;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.DynamicProgrammingLibrary.Interfaces
{
    public interface IMultithreadedCacheManager
    {
        public ICache<TKey, TValue> GetCache<TKey, TValue>(Func<TKey, TValue> valueFactory);
        public void RegisterCache<TKey, TValue>(Func<TKey, TValue> function);
        public TValue GetFromCache<TKey, TValue>(Func<TKey, TValue> valueFactory, TKey key);
        public TValue[] GetFromCache<TKey, TValue>(Func<TKey, TValue> valueFactory, TKey[] keys);
        public IList<TValue> GetFromCache<TKey, TValue>(Func<TKey, TValue> valueFactory, IList<TKey> keys);
        public bool ClearCache<TKey, TValue>(Func<TKey, TValue> valueFactory);
        public bool ClearAllCaches();
    }
}
