﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5
{
    public static class DynamicProgrammingHelper
    {
        private static void ExecuteTasksAndWaitAll(List<Task> taskList)
        {
            foreach (var task in taskList)
            {
                task.Start();
            }
            //Console.WriteLine($"Created {taskList.Count} tasks.");
            Task.WaitAll(taskList.ToArray());
            //Console.WriteLine($"Waited for {taskList.Count} tasks.");
        }

        #region Not depending on index
        public static void ExecuteParallelNTimes(Action action, int n)
        {
            var taskList = new List<Task>();
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    action();
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
        }
        public static TResult[] ExecuteParallelNTimes<TResult>(Func<TResult> function, int n)
        {
            var taskList = new List<Task>();
            var resultArray = new TResult[n];
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    resultArray[index] = function();
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
            return resultArray;
        }
        public static TResult[] ExecuteParallelNTimes<TInput, TResult>(Func<TInput, TResult> function, TInput[] input)
        {
            var taskList = new List<Task>();
            var n = input.Length;
            var resultArray = new TResult[n];
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    resultArray[index] = function(input[index]);
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
            return resultArray;
        }
        public static IList<TResult> ExecuteParallelNTimes<TInput, TResult>(Func<TInput, TResult> function, IList<TInput> input)
        {
            var taskList = new List<Task>();
            var n = input.Count;
            var resultArray = new TResult[n];
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    resultArray[index] = function(input[index]);
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
            return resultArray;
        }

        #endregion

        #region Depending on index
        public static void ExecuteParallelNTimes(Action<int> action, int n)
        {
            var taskList = new List<Task>();
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    action(index);
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
        }
        public static TResult[] ExecuteParallelNTimes<TResult>(Func<int, TResult> function, int n)
        {
            var taskList = new List<Task>();
            var resultArray = new TResult[n];
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    resultArray[index] = function(index);
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
            return resultArray;
        }
        public static TResult[] ExecuteParallelNTimes<TInput, TResult>(Func<TInput, int, TResult> function, TInput[] input)
        {
            var taskList = new List<Task>();
            var n = input.Length;
            var resultArray = new TResult[n];
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    resultArray[index] = function(input[index], index);
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
            return resultArray;
        }
        public static IList<TResult> ExecuteParallelNTimes<TInput, TResult>(Func<TInput, int, TResult> function, IList<TInput> input)
        {
            var taskList = new List<Task>();
            var n = input.Count;
            var resultArray = new TResult[n];
            for (int i = 0; i < n; i++)
            {
                int index = i;
                var task = new Task(() =>
                {
                    resultArray[index] = function(input[index], index);
                });
                taskList.Add(task);
            }
            ExecuteTasksAndWaitAll(taskList);
            return resultArray;
        }

        #endregion

    }
}
