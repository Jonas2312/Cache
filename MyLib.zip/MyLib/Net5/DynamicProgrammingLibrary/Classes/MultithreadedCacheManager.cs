﻿using Net5.DynamicProgrammingLibrary.Classes;
using Net5.DynamicProgrammingLibrary.Example;
using Net5.DynamicProgrammingLibrary.Interfaces;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Net5
{
    public abstract class MultithreadedCacheManager : IMultithreadedCacheManager
    {
        private IDictionary<object, object> _allCaches;

        public MultithreadedCacheManager()
        {
            _allCaches = new ConcurrentDictionary<object, object>();
        }

         
        protected void AddCache<TKey, TValue>(Func<TKey, TValue> valueFactory, ICache<TKey, TValue> cache)
        {
            _allCaches.Add(valueFactory, cache);
        }

        public ICache<TKey, TValue> GetCache<TKey, TValue>(Func<TKey, TValue> valueFactory)
        {
            object cacheObject = null;
            if (!_allCaches.TryGetValue(valueFactory, out cacheObject))
                throw new Exception($"Could not find Cache. Did you forget to register the cache for function {valueFactory.Method.Name}?");
            var cache = (ICache<TKey, TValue>)cacheObject;
            return cache;
        }

        public void RegisterCache<TKey, TValue>(Func<TKey, TValue> function)
        {
            AddCache(function, new DictionaryCache<TKey, TValue>());            
        }

        public TValue GetFromCache<TKey, TValue>(Func<TKey, TValue> valueFactory, TKey key)
        {
            var cache = GetCache(valueFactory);
            var associatedDictionary = cache.GetAssociatedDictionaryCache();
            if (associatedDictionary.ContainsKey(key))
                return associatedDictionary[key];
            return associatedDictionary.GetOrAdd(key, valueFactory(key));
        }

        public TValue[] GetFromCache<TKey, TValue>(Func<TKey, TValue> valueFactory, TKey[] keys)
        {
            var cache = GetCache(valueFactory);
            var associatedDictionary = cache.GetAssociatedDictionaryCache();

            var getFromCache = new Func<TKey, TValue>((TKey key) => { return GetFromCache(valueFactory, key); });
            var result = DynamicProgrammingHelper.ExecuteParallelNTimes(getFromCache, keys);
            return result;
        }

        public IList<TValue> GetFromCache<TKey, TValue>(Func<TKey, TValue> valueFactory, IList<TKey> keys)
        {
            var cache = GetCache(valueFactory);
            var associatedDictionary = cache.GetAssociatedDictionaryCache();

            var getFromCache = new Func<TKey, TValue>((TKey key) => { return GetFromCache(valueFactory, key); });
            var result = DynamicProgrammingHelper.ExecuteParallelNTimes(getFromCache, keys);
            return result;
        }

        public bool ClearCache<TKey, TValue>(Func<TKey, TValue> valueFactory)
        {
            object cacheObject = null;
            if (!_allCaches.TryGetValue(valueFactory, out cacheObject))
                throw new Exception("Could not find Cache. Did you forget to register the cache for function {valueFactory.Method.Name}?");
            var cache = (ICache<TKey, TValue>) cacheObject;
            cache.Clear();
            return true;
        }

        public bool ClearAllCaches()
        {
            foreach(var keyValuePair in _allCaches)
            {
                var cacheObject = keyValuePair.Value;
                MethodInfo clearMethod = cacheObject.GetType().GetMethod("Clear");
                clearMethod.Invoke(cacheObject, null);                
            }
            return true;
        }       


    }
}
