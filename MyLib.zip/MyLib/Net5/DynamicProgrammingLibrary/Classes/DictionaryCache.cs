﻿using Net5.DynamicProgrammingLibrary.Example;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net5.DynamicProgrammingLibrary.Classes
{
    public class DictionaryCache<TKey, TValue> : IDictionaryCache<TKey, TValue>
    {
        protected ConcurrentDictionary<TKey, TValue> _dictionaryCache;

        public DictionaryCache()
        {
            _dictionaryCache = new ConcurrentDictionary<TKey, TValue>();
        }
        public DictionaryCache(ConcurrentDictionary<TKey, TValue> dictionaryCache)
        {
            _dictionaryCache = dictionaryCache;
        }

        public void Clear()
        {
            _dictionaryCache.Clear();
        }

        public ConcurrentDictionary<TKey, TValue> GetAssociatedDictionaryCache()
        {
            return _dictionaryCache;
        }
    }
}
