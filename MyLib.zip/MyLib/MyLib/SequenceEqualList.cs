﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    class SequenceEqualList<T> : List<T>
    {
        public SequenceEqualList(IList<T> list)
        {
            foreach(var element in list)
            {
                Add(element);
            }
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            var hashCode = 1;
            foreach(var element in this)
            {
                hashCode = System.HashCode.Combine()
            }
            return base.GetHashCode();
        }

        public override string ToString()
        {
            var s = string.Empty;
            for(int i = 0; i < Count; i++)
            {
                s += this[i];
                if (i < Count - 1)
                    s += ", ";
            }
            return s;
        }
    }
}
