﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public abstract class MultithreadedCacheManager
    {
        public MultithreadedCacheManager()
        {
            Caches = new Dictionary<object, object>();
        }

        private IDictionary<object, object> Caches;

        protected void RegisterCache<TKey, TValue>(Func<TKey, TValue> function)
        {
            var newDictionary = new Dictionary<TKey, TValue>();
            Caches.Add(function, newDictionary);
        }

        protected TValue GetFromCache<TKey, TValue>(Func<TKey, TValue> functionToCalculate, TKey key)
        {
            var associatedDictionary = (IDictionary<TKey, TValue>) Caches[functionToCalculate];
            lock (associatedDictionary)
            {
                if (associatedDictionary.ContainsKey(key))
                    return associatedDictionary[key];
            }
            var calculatedValue = functionToCalculate(key);
            lock (associatedDictionary)
            {
                associatedDictionary.Add(key, calculatedValue);
                return calculatedValue;
            }
        }

    }
}
