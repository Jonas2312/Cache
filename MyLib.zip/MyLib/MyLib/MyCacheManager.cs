﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    class MyCacheManager : MultithreadedCacheManager, IMyCacheManager
    {
        public MyCacheManager()
        {
            RegisterCache<int, string>(CalculateStringFromInt);
            RegisterCache<string, int>(CalculateIntFromString);
        }


        public int GetIntFromString(string s)
        {
            return GetFromCache(CalculateIntFromString, s);
        }

        public string GetStringFromInt(int i)
        {
            return GetFromCache(CalculateStringFromInt, i);
        }

        private int CalculateIntFromString(string s)
        {
            return s.Length;
        }

        private string CalculateStringFromInt(int i)
        {
            Console.WriteLine("Generating string...");
            string s = string.Empty;
            for (int x = 0; x < i; x++)
                s += "-";
            return s;
        }
    }
}
